// pages/Login.jsx
// eslint-disable-next-line no-unused-vars
import React, { useState } from "react";
import {  useLocation } from "react-router-dom";
import AuthForm from "../components/AuthForm";

const Login = () => {

  // eslint-disable-next-line no-unused-vars
  const navigate = useLocation();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-600 p-4">
      <div className="w-full max-w-5xl flex rounded-2xl shadow-2xl overflow-hidden bg-white">
        {/* Image côté gauche */}
        <div className="hidden md:block w-1/2 bg-cover bg-center" 
             style={{ backgroundImage: "url('https://images.unsplash.com/photo-1604719312566-8912e9227c6a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80')" }}>
          <div className="h-full w-full bg-black bg-opacity-30 flex flex-col justify-between p-12">
            <div>
              <h2 className="text-white text-4xl font-bold mb-2">MagasinPro</h2>
              <p className="text-white text-lg">Gestion centralisée de votre réseau de magasins</p>
            </div>
            <div className="text-white">
              <p className="text-sm">© 2023 MagasinPro. Tous droits réservés.</p>
            </div>
          </div>
        </div>
        
        {/* Formulaire côté droit */}
        <div className="w-full md:w-1/2 py-12 px-8 md:px-12">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Bienvenue</h1>
            <p className="text-gray-600">Connectez-vous à votre espace de gestion</p>
          </div>
          
          <AuthForm isLogin={true} />
          
        </div>
      </div>
    </div>
  );
};

export default Login;
