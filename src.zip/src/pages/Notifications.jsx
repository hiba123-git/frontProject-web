// eslint-disable-next-line no-unused-vars
import React, { useState } from 'react';
import { FaBell, FaBox, FaExclamationCircle, FaCheck } from 'react-icons/fa';

const Notifications = () => {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'restock',
      message: 'Nouvelle demande de réapprovisionnement - Magasin Paris',
      time: '5 min ago',
      read: false,
      priority: 'high'
    },
    // Add more notifications
  ]);

  const markAsRead = (id) => {
    setNotifications(notifications.map(notif => 
      notif.id === id ? { ...notif, read: true } : notif
    ));
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-3xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <FaBell className="mr-3 text-indigo-600" />
            Notifications
          </h1>
          <button className="text-indigo-600 hover:text-indigo-800">
            Tout marquer comme lu
          </button>
        </div>

        <div className="space-y-4">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              className={`bg-white rounded-lg shadow-md p-4 border-l-4 
                ${notif.priority === 'high' ? 'border-red-500' : 
                  notif.priority === 'medium' ? 'border-yellow-500' : 
                  'border-green-500'}
                ${!notif.read ? 'bg-indigo-50' : ''}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <div className="mt-1">
                    {notif.type === 'restock' ? (
                      <FaBox className="text-indigo-600" />
                    ) : (
                      <FaExclamationCircle className="text-red-600" />
                    )}
                  </div>
                  <div>
                    <p className="text-gray-900 font-medium">{notif.message}</p>
                    <p className="text-gray-500 text-sm">{notif.time}</p>
                  </div>
                </div>
                {!notif.read && (
                  <button
                    onClick={() => markAsRead(notif.id)}
                    className="text-indigo-600 hover:text-indigo-800"
                  >
                    <FaCheck />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Notifications;