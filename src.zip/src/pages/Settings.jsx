"use client"

// eslint-disable-next-line no-unused-vars
import { useState } from "react"
import { FaStore } from "react-icons/fa"

const Settings = () => {
  const [storeName, setStoreName] = useState("Magasin Central Paris")
  const [storeAddress, setStoreAddress] = useState("123 Rue de Paris, 75001 Paris")
  const [storeEmail, setStoreEmail] = useState("contact@magasincentral.fr")
  const [storePhone, setStorePhone] = useState("01 23 45 67 89")
  const [showModal, setShowModal] = useState(false)
  const [tempStoreInfo, setTempStoreInfo] = useState({
    name: storeName,
    address: storeAddress,
    email: storeEmail,
    phone: storePhone,
  })

  const handleSave = () => {
    setStoreName(tempStoreInfo.name)
    setStoreAddress(tempStoreInfo.address)
    setStoreEmail(tempStoreInfo.email)
    setStorePhone(tempStoreInfo.phone)
    setShowModal(false)
    alert("Paramètres sauvegardés avec succès !")
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setTempStoreInfo((prev) => ({ ...prev, [name]: value }))
  }

  return (
    <div className="min-h-screen bg-indigo-100 p-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-2 bg-indigo-200 rounded-lg">
            <FaStore className="text-indigo-600 text-xl" />
          </div>
          <h1 className="text-2xl font-bold text-indigo-800">Informations du Magasin</h1>
        </div>

        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="bg-indigo-500 p-6">
            <h2 className="text-xl font-semibold text-white">Configuration du magasin</h2>
            <p className="text-indigo-100 mt-1">Gérez les informations de votre établissement</p>
          </div>

          <div className="p-6 space-y-6">
            <div>
              <label className="block text-sm font-medium text-indigo-700">Nom du Magasin</label>
              <p className="mt-1 p-2 w-full rounded-md border border-indigo-300 bg-indigo-50">{storeName}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-indigo-700">Adresse</label>
              <p className="mt-1 p-2 w-full rounded-md border border-indigo-300 bg-indigo-50">{storeAddress}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-indigo-700">Email</label>
                <p className="mt-1 p-2 w-full rounded-md border border-indigo-300 bg-indigo-50">{storeEmail}</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-indigo-700">Téléphone</label>
                <p className="mt-1 p-2 w-full rounded-md border border-indigo-300 bg-indigo-50">{storePhone}</p>
              </div>
            </div>

            <div className="pt-4">
              <button
                onClick={() => setShowModal(true)}
                className="w-full bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition duration-200"
              >
                Modifier les informations
              </button>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full mx-4">
            <div className="p-6 border-b border-indigo-200">
              <h3 className="text-xl font-semibold text-indigo-800">Modifier les informations</h3>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-indigo-700">Nom du Magasin</label>
                <input
                  type="text"
                  name="name"
                  value={tempStoreInfo.name}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-indigo-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-indigo-700">Adresse</label>
                <input
                  type="text"
                  name="address"
                  value={tempStoreInfo.address}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-indigo-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-indigo-700">Email</label>
                <input
                  type="email"
                  name="email"
                  value={tempStoreInfo.email}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-indigo-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-indigo-700">Téléphone</label>
                <input
                  type="tel"
                  name="phone"
                  value={tempStoreInfo.phone}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-indigo-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="p-6 bg-indigo-50 flex justify-end space-x-3">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 text-sm font-medium text-indigo-600 hover:text-indigo-800"
              >
                Annuler
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700"
              >
                Sauvegarder
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Settings

