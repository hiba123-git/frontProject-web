// eslint-disable-next-line no-unused-vars
import React, { useState, useEffect } from 'react';
import { FaEdit, FaTrash, FaBell, FaUserPlus } from 'react-icons/fa';
import axios from 'axios';

const UserManagement = () => {
  const [users, setUsers] = useState([
    {
      id: 1,
      nom: 'Dupont',
      prenom: 'Jean',
      login: 'jean',
      telephone: '0612345678',
      magasin: 'Magasin Central Paris',
      image: 'https://via.placeholder.com/40',
      role: 'Gérant',
    },
    // Ajoutez plus d'utilisateurs ici
  ]);
  const [showModal, setShowModal] = useState(false);
  const [showNotifyModal, setShowNotifyModal] = useState(false);
  const [formData, setFormData] = useState({
    nom: '',
    prenom: '',
    login: '',
    password: '',
    telephone: '',
    magasin: '',
    image: null,
    role: 'Employé',
  });
  const [notifyEmail, setNotifyEmail] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [selectedUserId, setSelectedUserId] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get('http://localhost:7000/users/all', {
          headers : {
            "Authorization" : `Bearer ${localStorage.getItem("token")}`
          }
        });
        setUsers(response.data);
      } catch (error) {
        console.error('Erreur lors de la récupération des utilisateurs:', error);
        alert('Erreur lors de la récupération des utilisateurs');
      }
    };
    fetchUsers();
  }, [reloadKey]);

  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    if (name === 'image') {
      setFormData({ ...formData, image: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formDataToSend = new FormData();
      Object.keys(formData).forEach((key) => {
        formDataToSend.append(key, formData[key]);
      });
      if (editingId) {
        await axios.put(`http://localhost:7000/users/${editingId}`, formDataToSend);
      } else {
        await axios.post('http://localhost:7000/users/signup', formDataToSend);
      }
      setShowModal(false);
      setFormData({
        nom: '',
        prenom: '',
        login: '',
        password: '',
        telephone: '',
        magasin: '',
        image: null,
        role: 'Employé',
      });
      setEditingId(null);
      setReloadKey((prev) => prev + 1);
    } catch (error) {
      console.error('Erreur:', error);
      alert(error.response?.data?.message || 'Une erreur est survenue');
    }
  };

  const handleEdit = (user) => {
    setFormData({
      nom: user.nom,
      prenom: user.prenom,
      login: user.login,
      telephone: user.telephone,
      magasin: user.magasin,
      image: user.image,
      role: user.role,
    });
    setEditingId(user.id);
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
      try {
        await axios.delete(`http://localhost:7000/users/${id}`);
        setReloadKey((prev) => prev + 1);
      } catch (error) {
        console.error('Erreur lors de la suppression:', error);
        alert('Erreur lors de la suppression');
      }
    }
  };

  const handleNotify = (userId) => {
    setSelectedUserId(userId);
    setShowNotifyModal(true);
  };

  const handleSendNotification = async () => {
    try {
      const user = users.find(u => u.id === selectedUserId);
      // eslint-disable-next-line no-unused-vars
      const response = await axios.post(`http://localhost:7000/notifications/send`, {
        email: notifyEmail,
        login: user.login,
        password: user.password,
      });
      alert('Notification envoyée avec succès');
      setShowNotifyModal(false);
    } catch (error) {
      console.error('Erreur lors de l\'envoi de la notification:', error);
      alert('Erreur lors de l\'envoi de la notification');
    }
  };

  return (
    <div className="flex-1 p-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">Gestion des Utilisateurs</h1>
          <button
            onClick={() => setShowModal(true)}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg flex items-center space-x-2 hover:bg-blue-700 transition duration-200 shadow-lg"
          >
            <FaUserPlus className="text-lg" />
            <span>Ajouter un utilisateur</span>
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-blue-50">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-blue-600 uppercase">Image</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-blue-600 uppercase">Nom & Prénom</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-blue-600 uppercase">Login</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-blue-600 uppercase">Téléphone</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-blue-600 uppercase">Point de Vente</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-blue-600 uppercase">Rôle</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-blue-600 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50 transition duration-200">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <img
                      src={user.image || 'https://via.placeholder.com/40'}
                      alt={`${user.nom} ${user.prenom}`}
                      className="h-10 w-10 rounded-full object-cover"
                    />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {user.nom} {user.prenom}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">{user.login}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">{user.telephone}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-3 py-1 text-sm font-semibold bg-blue-100 text-blue-800 rounded-full">
                      {user.magasin}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-3 py-1 text-sm font-semibold bg-green-100 text-green-800 rounded-full">
                      {user.role}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-3">
                    <button
                      onClick={() => handleEdit(user)}
                      className="text-blue-600 hover:text-blue-900 transition duration-200"
                    >
                      <FaEdit className="inline-block" />
                    </button>
                    <button
                      onClick={() => handleDelete(user.id)}
                      className="text-red-600 hover:text-red-900 transition duration-200"
                    >
                      <FaTrash className="inline-block" />
                    </button>
                    <button
                      onClick={() => handleNotify(user.id)}
                      className="text-yellow-600 hover:text-yellow-900 transition duration-200"
                    >
                      <FaBell className="inline-block" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-2xl w-11/12 max-w-lg">
              <div className="flex justify-between items-center p-6 border-b">
                <h3 className="text-xl font-semibold text-gray-800">
                  {editingId ? 'Modifier' : 'Ajouter'} un utilisateur
                </h3>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-gray-600 transition duration-200"
                >
                  ×
                </button>
              </div>
              <form onSubmit={handleSubmit} className="p-6 space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Nom</label>
                  <input
                    type="text"
                    name="nom"
                    value={formData.nom}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Prénom</label>
                  <input
                    type="text"
                    name="prenom"
                    value={formData.prenom}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Login</label>
                  <input
                    type="text"
                    name="login"
                    value={formData.login}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                {!editingId && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Mot de passe</label>
                    <input
                      type="password"
                      name="password"
                      value={formData.password}
                      onChange={handleInputChange}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      required={!editingId}
                    />
                  </div>
                )}
                <div>
                  <label className="block text-sm font-medium text-gray-700">Téléphone</label>
                  <input
                    type="tel"
                    name="telephone"
                    value={formData.telephone}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Point de Vente</label>
                  <input
                    type="text"
                    name="magasin"
                    value={formData.magasin}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Rôle</label>
                  <select
                    name="role"
                    value={formData.role}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  >
                    <option value="Gérant">Gérant</option>
                    <option value="Employé">Employé</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Image</label>
                  <input
                    type="file"
                    name="image"
                    onChange={handleInputChange}
                    className="mt-1 block w-full"
                    accept="image/*"
                  />
                </div>
                <div className="flex justify-end space-x-4">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300 transition duration-200"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition duration-200"
                  >
                    {editingId ? 'Modifier' : 'Ajouter'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showNotifyModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-2xl w-11/12 max-w-lg">
              <div className="flex justify-between items-center p-6 border-b">
                <h3 className="text-xl font-semibold text-gray-800">Envoyer une notification</h3>
                <button
                  onClick={() => setShowNotifyModal(false)}
                  className="text-gray-400 hover:text-gray-600 transition duration-200"
                >
                  ×
                </button>
              </div>
              <div className="p-6 space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    type="email"
                    value={notifyEmail}
                    onChange={(e) => setNotifyEmail(e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <div className="flex justify-end space-x-4">
                  <button
                    type="button"
                    onClick={() => setShowNotifyModal(false)}
                    className="bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300 transition duration-200"
                  >
                    Annuler
                  </button>
                  <button
                    type="button"
                    onClick={handleSendNotification}
                    className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition duration-200"
                  >
                    Envoyer
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
  );
};

export default UserManagement;