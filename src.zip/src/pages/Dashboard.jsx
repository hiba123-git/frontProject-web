// eslint-disable-next-line no-unused-vars
import React from 'react';
//import Sidebar from '../components/Sidebar';
//import Navbar from '../components/Navbar';
//import { motion } from 'framer-motion';
import { FaStore, FaBox, FaChartLine, FaExclamationTriangle } from 'react-icons/fa';
import { LineChart, Line, PieChart, Pie, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';

const Dashboard = () => {
  const salesData = [
    { month: 'Jan', ventes: 4000, demandes: 2400, profit: 2400 },
    { month: 'Fév', ventes: 5000, demandes: 3398, profit: 2800 },
    { month: 'Mar', ventes: 6000, demandes: 4800, profit: 3200 },
    { month: 'Avr', ventes: 4780, demandes: 3908, profit: 2900 },
    { month: 'Mai', ventes: 5890, demandes: 4800, profit: 3400 },
    { month: 'Jun', ventes: 6390, demandes: 5800, profit: 3700 },
  ];

  const stockData = [
    { name: 'Électronique', value: 400, color: '#3B82F6' },
    { name: 'Vêtements', value: 300, color: '#10B981' },
    { name: 'Accessoires', value: 300, color: '#F59E0B' },
    { name: 'Autres', value: 200, color: '#6366F1' },
  ];

  const stats = [
    {
      title: 'Points de Vente',
      value: '12',
      change: '+2',
      icon: FaStore,
      color: 'bg-blue-500',
      detail: 'Actifs ce mois'
    },
    {
      title: 'Demandes en Attente',
      value: '25',
      change: '+5',
      icon: FaBox,
      color: 'bg-yellow-500',
      detail: 'À traiter'
    },
    {
      title: "Chiffre d'Affaires",
      value: '45K €',
      change: '+12%',
      icon: FaChartLine,
      color: 'bg-green-500',
      detail: 'Ce mois'
    },
    {
      title: 'Alertes Stock',
      value: '8',
      change: '-3',
      icon: FaExclamationTriangle,
      color: 'bg-red-500',
      detail: 'Produits'
    }
  ];

  

  return (
    <>
      <div className="p-6 bg-gray-50">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800">Tableau de Bord</h1>
          <p className="text-gray-600">Vue d ensemble de votre magasin central</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`${stat.color} rounded-full p-3`}>
                    <stat.icon className="h-6 w-6 text-white" />
                  </div>
                  <span className={`text-sm font-semibold ${
                    stat.change.startsWith('+') ? 'text-green-500' : 'text-red-500'
                  }`}>
                    {stat.change}
                  </span>
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h2>
                <p className="text-sm text-gray-600">{stat.title}</p>
                <p className="text-xs text-gray-500 mt-2">{stat.detail}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-800">Performance des Ventes</h2>
              <select className="text-sm border rounded-lg px-3 py-1">
                <option>6 derniers mois</option>
                <option>Cette année</option>
              </select>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.15)' }}
                />
                <Legend />
                <Line type="monotone" dataKey="ventes" stroke="#3B82F6" strokeWidth={2} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="profit" stroke="#10B981" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-800">Répartition du Stock</h2>
              <button className="text-blue-500 hover:text-blue-700 text-sm">
                Voir détails
              </button>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={stockData}
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {stockData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-white rounded-xl shadow-md p-6 lg:col-span-2">
            <h2 className="text-xl font-semibold text-gray-800 mb-6">Demandes Récentes</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">Magasin</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">Produit</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">Quantité</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">Statut</th>
                  </tr>
                </thead>
                <tbody>
                {/* Exemple de données */}
                <tr className="border-b">
                  <td className="py-3 px-4">Paris Centre</td>
                  <td className="py-3 px-4">iPhone 13</td>
                  <td className="py-3 px-4">50</td>
                  <td className="py-3 px-4">
                    <span className="bg-yellow-100 text-yellow-800 text-xs font-semibold px-2.5 py-0.5 rounded">
                      En attente
                    </span>
                  </td>
                </tr>
                {/* Ajoutez plus de lignes ici */}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-6">Alertes Stock</h2>
          <div className="space-y-4">
            {/* Exemple d'alertes */}
            <div className="flex items-center p-3 bg-red-50 rounded-lg">
              <FaExclamationTriangle className="text-red-500 mr-3" />
              <div>
                <p className="text-sm font-medium text-red-800">Stock critique</p>
                <p className="text-xs text-red-600">iPhone 13 - 5 unités restantes</p>
              </div>
            </div>
            {/* Ajoutez plus d'alertes ici */}
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default Dashboard;