"use client"

// eslint-disable-next-line no-unused-vars
import { useState } from "react"
import { FaCalendar, FaPercent, FaEdit, FaTrash, FaPlus } from "react-icons/fa"

const PromotionsManagement = () => {
  const [promotions, setPromotions] = useState([
    {
      id: 1,
      title: "Soldes d'été",
      type: "Saisonnière",
      discount: 30,
      startDate: "2024-06-01",
      endDate: "2024-06-30",
      products: ["Smartphones", "Tablettes"],
      stores: ["Paris", "Lyon"],
      status: "scheduled",
    },
    {
      id: 2,
      title: "Black Friday",
      type: "Événement",
      discount: 50,
      startDate: "2024-11-25",
      endDate: "2024-11-27",
      products: ["Électroménager", "TV"],
      stores: ["Paris", "Marseille", "Lille"],
      status: "active",
    },
    {
      id: 3,
      title: "Promotion Flash",
      type: "Flash",
      discount: 20,
      startDate: "2024-03-15",
      endDate: "2024-03-16",
      products: ["Vêtements", "Chaussures"],
      stores: ["Toulouse", "Bordeaux"],
      status: "expired",
    },
  ])

  const [showModal, setShowModal] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    type: "",
    discount: "",
    startDate: "",
    endDate: "",
    products: [],
    stores: [],
    status: "scheduled",
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const newPromotion = {
      id: promotions.length + 1,
      ...formData,
    }
    setPromotions([...promotions, newPromotion])
    setShowModal(false)
    setFormData({
      title: "",
      type: "",
      discount: "",
      startDate: "",
      endDate: "",
      products: [],
      stores: [],
      status: "scheduled",
    })
  }

  const handleDelete = (id) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer cette promotion ?")) {
      setPromotions(promotions.filter((promo) => promo.id !== id))
    }
  }

  return (
    <div className="p-6 bg-gradient-to-r from-gray-50 to-gray-100 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Gestion des Promotions</h1>
          <button
            onClick={() => setShowModal(true)}
            className="bg-indigo-500 text-white px-6 py-3 rounded-lg hover:bg-indigo-600 flex items-center space-x-2 transition duration-200 shadow-md"
          >
            <FaPlus className="text-lg" />
            <span>Nouvelle Promotion</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {promotions.map((promo) => (
            <div
              key={promo.id}
              className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden border border-indigo-50"
            >
              <div className="bg-gradient-to-r from-indigo-400 to-indigo-500 p-6">
                <h3 className="text-2xl font-bold text-white">{promo.title}</h3>
                <span className="inline-block bg-white bg-opacity-30 rounded-full px-4 py-1 text-sm text-white mt-2">
                  {promo.type}
                </span>
              </div>

              <div className="p-6">
                <div className="flex items-center mb-4">
                  <FaPercent className="text-indigo-500 mr-2" />
                  <span className="text-2xl font-bold text-gray-900">{promo.discount}% OFF</span>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center text-gray-600">
                    <FaCalendar className="mr-2" />
                    <span>
                      Du {promo.startDate} au {promo.endDate}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {promo.products.map((product, index) => (
                      <span key={index} className="bg-slate-100 rounded-full px-3 py-1 text-sm text-slate-700">
                        {product}
                      </span>
                    ))}
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {promo.stores.map((store, index) => (
                      <span key={index} className="bg-indigo-50 rounded-full px-3 py-1 text-sm text-indigo-600">
                        {store}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6 flex justify-between items-center">
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-semibold
                      ${
                        promo.status === "active"
                          ? "bg-emerald-50 text-emerald-700"
                          : promo.status === "scheduled"
                            ? "bg-sky-50 text-sky-700"
                            : "bg-slate-50 text-slate-700"
                      }`}
                  >
                    {promo.status.toUpperCase()}
                  </span>
                  <div className="flex space-x-4">
                    <button className="text-indigo-600 hover:text-indigo-800">
                      <FaEdit className="inline-block" />
                    </button>
                    <button onClick={() => handleDelete(promo.id)} className="text-red-600 hover:text-red-800">
                      <FaTrash className="inline-block" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-2xl w-11/12 max-w-lg">
            <div className="flex justify-between items-center p-6 border-b">
              <h3 className="text-xl font-bold text-gray-800">Nouvelle Promotion</h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-600 transition duration-200"
              >
                ×
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Titre</label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Type</label>
                <select
                  name="type"
                  value={formData.type}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  required
                >
                  <option value="">Sélectionnez un type</option>
                  <option value="Saisonnière">Saisonnière</option>
                  <option value="Événement">Événement</option>
                  <option value="Flash">Flash</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Réduction (%)</label>
                <input
                  type="number"
                  name="discount"
                  value={formData.discount}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Date de début</label>
                <input
                  type="date"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Date de fin</label>
                <input
                  type="date"
                  name="endDate"
                  value={formData.endDate}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Produits concernés</label>
                <input
                  type="text"
                  name="products"
                  value={formData.products.join(", ")}
                  onChange={(e) => setFormData({ ...formData, products: e.target.value.split(", ") })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Magasins concernés</label>
                <input
                  type="text"
                  name="stores"
                  value={formData.stores.join(", ")}
                  onChange={(e) => setFormData({ ...formData, stores: e.target.value.split(", ") })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  required
                />
              </div>
              <div className="flex justify-end space-x-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300 transition duration-200"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="bg-indigo-500 text-white px-6 py-2 rounded-md hover:bg-indigo-600 transition duration-200"
                >
                  Créer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

export default PromotionsManagement

