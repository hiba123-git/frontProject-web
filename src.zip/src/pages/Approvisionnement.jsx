// eslint-disable-next-line no-unused-vars
import React, { useState } from 'react';
import { FaCheck, FaTimes, FaClock, FaSearch } from 'react-icons/fa';

const Approvisionnement = () => {
  const [requests, setRequests] = useState([
    {
      id: 1,
      productName: 'Smartphone XYZ',
      quantity: 50,
      requestDate: '2024-02-15',
      expectedDeliveryDate: '2024-02-20',
      status: 'pending',
      store: 'Point de Vente Paris',
      urgency: 'high',
      currentStock: 10,
      supplier: 'Fournisseur A',
    },
    {
      id: 2,
      productName: 'Tablette ABC',
      quantity: 30,
      requestDate: '2024-02-16',
      expectedDeliveryDate: '2024-02-22',
      status: 'approved',
      store: 'Point de Vente Lyon',
      urgency: 'medium',
      currentStock: 5,
      supplier: 'Fournisseur B',
    },
    {
      id: 3,
      productName: 'Ordinateur Portable',
      quantity: 20,
      requestDate: '2024-02-17',
      expectedDeliveryDate: '2024-02-25',
      status: 'rejected',
      store: 'Point de Vente Marseille',
      urgency: 'low',
      currentStock: 15,
      supplier: 'Fournisseur C',
    },
  ]);

  const [filter, setFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredRequests = requests.filter((request) => {
    const matchesFilter =
      filter === 'all' || request.status === filter;
    const matchesSearch = request.productName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const handleApprove = (id) => {
    setRequests(requests.map((request) =>
      request.id === id ? { ...request, status: 'approved' } : request
    ));
  };

  const handleReject = (id) => {
    setRequests(requests.map((request) =>
      request.id === id ? { ...request, status: 'rejected' } : request
    ));
  };

  const handleReapprovisionnement = (id) => {
    // Logique pour gérer le réapprovisionnement
    alert(`Réapprovisionnement effectué pour la demande ${id}`);
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Demandes de Réapprovisionnement</h1>

        {/* Filtres et Recherche */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 space-y-4 md:space-y-0">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-lg ${
                filter === 'all'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } transition duration-200`}
            >
              Toutes
            </button>
            <button
              onClick={() => setFilter('pending')}
              className={`px-4 py-2 rounded-lg ${
                filter === 'pending'
                  ? 'bg-yellow-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } transition duration-200`}
            >
              En Attente
            </button>
            <button
              onClick={() => setFilter('approved')}
              className={`px-4 py-2 rounded-lg ${
                filter === 'approved'
                  ? 'bg-green-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } transition duration-200`}
            >
              Approuvées
            </button>
            <button
              onClick={() => setFilter('rejected')}
              className={`px-4 py-2 rounded-lg ${
                filter === 'rejected'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } transition duration-200`}
            >
              Rejetées
            </button>
          </div>
          <div className="relative">
            <input
              type="text"
              placeholder="Rechercher une demande..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-blue-500"
            />
            <FaSearch className="absolute left-3 top-3 text-gray-400" />
          </div>
        </div>

        {/* Liste des Demandes */}
        <div className="grid gap-6">
          {filteredRequests.map((request) => (
            <div
              key={request.id}
              className={`bg-white rounded-xl shadow-lg p-6 border-l-4 ${
                request.urgency === 'high'
                  ? 'border-red-500'
                  : request.urgency === 'medium'
                  ? 'border-yellow-500'
                  : 'border-green-500'
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{request.productName}</h3>
                  <p className="text-gray-600">Point de vente: {request.store}</p>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleApprove(request.id)}
                    className="p-2 text-green-600 hover:bg-green-100 rounded"
                  >
                    <FaCheck />
                  </button>
                  <button
                    onClick={() => handleReject(request.id)}
                    className="p-2 text-red-600 hover:bg-red-100 rounded"
                  >
                    <FaTimes />
                  </button>
                  <button
                    onClick={() => handleReapprovisionnement(request.id)}
                    className="p-2 text-blue-600 hover:bg-blue-100 rounded"
                  >
                    Réappro
                  </button>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center">
                  <div className="text-gray-600">Quantité demandée:</div>
                  <div className="ml-2 font-semibold">{request.quantity}</div>
                </div>
                <div className="flex items-center">
                  <FaClock className="text-gray-400 mr-2" />
                  <div className="text-gray-600">Date prévue:</div>
                  <div className="ml-2 font-semibold">{request.expectedDeliveryDate}</div>
                </div>
                <div className="flex items-center">
                  <div
                    className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      request.status === 'pending'
                        ? 'bg-yellow-100 text-yellow-800'
                        : request.status === 'approved'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                  </div>
                </div>
              </div>

              {/* Détails Supplémentaires */}
              <div className="mt-4 text-sm text-gray-600">
                <p>Stock actuel: {request.currentStock}</p>
                <p>Fournisseur: {request.supplier}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Approvisionnement;