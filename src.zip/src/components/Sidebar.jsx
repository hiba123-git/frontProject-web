/* eslint-disable react/prop-types */
// eslint-disable-next-line no-unused-vars
import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  FaChartPie, 
  FaUsers, 
  FaBoxes, 
  FaPercentage, 
  FaBell, 
  FaCog, 
  FaSignOutAlt,
  FaStore,
  FaChevronDown,
  FaChevronRight,
  FaChevronLeft
} from 'react-icons/fa';

const Sidebar = (props) => {
  const location = useLocation();
  const [expandedMenu, setExpandedMenu] = useState(null);
  const [isCollapsed, setIsCollapsed] = useState(false);

  const menuItems = [
    {
      title: 'Tableau de bord',
      icon: <FaChartPie />,
      path: '/dashboard',
    },
    {
      title: 'Gestion des utilisateurs',
      icon: <FaUsers />,
      path: '/users',
    },
    {
      title: 'Réapprovisionnement',
      icon: <FaBoxes />,
      path: '/approvisionnement',
      submenu: [
        { title: 'Demandes', path: '/approvisionnement' }
      ]
    },
    {
      title: 'Promotions',
      icon: <FaPercentage />,
      path: '/promotions',
    },
    {
      title: 'Notifications',
      icon: <FaBell />,
      path: '/notifications',
      badge: 3
    },
    {
      title: 'Paramètres',
      icon: <FaCog />,
      path: '/settings',
    },
  ];

  const toggleSubmenu = (index) => {
    if (expandedMenu === index) {
      setExpandedMenu(null);
    } else {
      setExpandedMenu(index);
    }
  };

  useEffect(() => {
    props.setCollapsed(isCollapsed)
  }, [isCollapsed])

  function Logout() {
    localStorage.removeItem("token");
    window.location.href = "/login";
  }

  return (
    <div className={`h-full flex flex-col bg-gradient-to-b from-indigo-800 to-indigo-900 text-white transition-all duration-300 ${isCollapsed ? 'w-20' : 'w-72'}`}>
      <div className="p-5 flex items-center space-x-3 border-b border-indigo-700">
        <FaStore className="h-8 w-8 text-white flex-shrink-0" />
        {!isCollapsed && (
          <div>
            <h1 className="text-xl font-bold">MagasinCentral</h1>
            <p className="text-xs text-indigo-300">Gestion centralisée</p>
          </div>
        )}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="ml-auto text-indigo-300 hover:text-white transition-colors"
        >
          {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
        </button>
      </div>
      
      <div className="p-4 border-b border-indigo-700">
        <div className="flex items-center space-x-3">
          <img 
            src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
            alt="Profile" 
            className="h-10 w-10 rounded-full border-2 border-indigo-400"
          />
          {!isCollapsed && (
            <div>
              <h2 className="font-semibold">Ahmed Benali</h2>
              <p className="text-xs text-indigo-300">Administrateur</p>
            </div>
          )}
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto py-4 px-3">
        <ul className="space-y-1">
          {menuItems.map((item, index) => (
            <li key={index}>
              {item.submenu ? (
                <div>
                  <button
                    onClick={() => toggleSubmenu(index)}
                    className={`flex items-center justify-between w-full px-4 py-3 text-sm rounded-lg transition-colors ${location.pathname.startsWith(item.path) ? 'bg-indigo-700 text-white' : 'text-indigo-100 hover:bg-indigo-700'}`}
                  >
                    <div className="flex items-center">
                      <span className="text-lg">{item.icon}</span>
                      {!isCollapsed && <span className="ml-3">{item.title}</span>}
                    </div>
                    {!isCollapsed && (expandedMenu === index ? <FaChevronDown /> : <FaChevronRight />)}
                  </button>
                  
                  {expandedMenu === index && !isCollapsed && (
                    <ul className="pl-10 mt-1 space-y-1">
                      {item.submenu.map((subItem, subIndex) => (
                        <li key={subIndex}>
                          <Link
                            to={subItem.path}
                            className={`flex items-center px-4 py-2 text-sm rounded-lg transition-colors ${location.pathname === subItem.path ? 'bg-indigo-600 text-white' : 'text-indigo-200 hover:bg-indigo-700'}`}
                          >
                            {subItem.title}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ) : (
                <Link
                  to={item.path}
                  className={`flex items-center px-4 py-3 text-sm rounded-lg transition-colors ${location.pathname === item.path ? 'bg-indigo-700 text-white' : 'text-indigo-100 hover:bg-indigo-700'}`}
                >
                  <span className="text-lg">{item.icon}</span>
                  {!isCollapsed && (
                    <>
                      <span className="ml-3">{item.title}</span>
                      {item.badge && (
                        <span className="ml-auto bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                          {item.badge}
                        </span>
                      )}
                    </>
                  )}
                </Link>
              )}
            </li>
          ))}
        </ul>
      </div>
      
      <div className="p-4 border-t border-indigo-700">
        <button className="flex items-center w-full px-4 py-2 text-sm text-indigo-100 hover:bg-indigo-700 rounded-lg transition-colors">
          <FaSignOutAlt className="text-lg" />
          {!isCollapsed && <span className="ml-3" onClick={() => Logout()}>Déconnexion</span>}
        </button>
      </div>
    </div>
  );
};
export default Sidebar;